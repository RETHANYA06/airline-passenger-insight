# Airline Passenger Insight — Practice Dataset

This is a **synthetic practice dataset generated for the CH11 DS Sprint assessment** based on the field descriptions in the provided assessment PDF. It is not real AeroVista Airways data.

## Files
- `passengers.csv`: Passenger_ID, Traveller_Type, Age_Band, Loyalty_Status
- `flights.csv`: Flight_ID, Passenger_ID, Route, Travel_Class, Distance_km, Departure_Time
- `delays.csv`: Flight_ID, Departure_Delay_min, Arrival_Delay_min
- `service_scores.csv`: Flight_ID, Checkin_Rating, Seat_Rating, Food_Rating, Staff_Rating, Baggage_Rating
- `feedback.csv`: Flight_ID, Overall_Satisfaction, Comments_Category
- `airline_passenger_insight_combined.csv`: merged analysis-ready table after removing duplicate passenger-flight record

## Data notes
- 500 generated passenger/flight observations.
- Assessment-style quality issues intentionally included: missing values, inconsistent class labels, a duplicate flight-passenger row, and extreme arrival delays.
- Ratings use a 1–5 scale; delay values are in minutes; distance is in kilometers.
- The satisfaction labels were generated synthetically for practice. Any EDA/model results are valid only for this generated data, not real airline operations.
